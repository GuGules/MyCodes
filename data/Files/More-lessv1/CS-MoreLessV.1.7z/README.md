# Lancer le serveur PHP

`php -S localhost:8000 -t .`
