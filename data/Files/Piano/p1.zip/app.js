var Cbleep = new Audio()
Cbleep.src ="Music_Note/C.wav";

var Dbleep = new Audio()
Dbleep.src = "Music_Note/D.wav";

var Ebleep = new Audio()
Ebleep.src = "Music_Note/E.wav";

var Csbleep = new Audio()
Csbleep.src ="Music_Note/C_s.wav";

var Dsbleep = new Audio()
Dsbleep.src ="Music_Note/D_s.wav";

var Fbleep = new Audio()
Fbleep.src ="Music_Note/F.wav";

var Gbleep = new Audio()
Gbleep.src ="Music_Note/G.wav";

var Ableep = new Audio()
Ableep.src ="Music_Note/A.wav";

var Bbleep = new Audio()
Bbleep.src ="Music_Note/B.wav";

var C1bleep = new Audio()
C1bleep.src ="Music_Note/C1.wav";

var D1bleep = new Audio()
D1bleep.src ="Music_Note/D1.wav";

var E1bleep = new Audio()
E1bleep.src ="Music_Note/E1.wav";

var F1bleep = new Audio()
F1bleep.src ="Music_Note/F1.wav";

var Fsbleep = new Audio()
Fsbleep.src ="Music_Note/F_s.wav";

var Gsbleep = new Audio()
Gsbleep.src ="Music_Note/G_s.wav";

var Bbbleep = new Audio()
Bbbleep.src ="Music_Note/Bb.wav";

var Cs1bleep = new Audio()
Cs1bleep.src ="Music_Note/C_s1.wav";

var Ds1bleep = new Audio()
Ds1bleep.src ="Music_Note/D_s1.wav";